export default  {
    data() {
        return {
            msg: '小马哥'
        }
    },
    template: `
                <h3>{{msg}}</h3>
            `

}