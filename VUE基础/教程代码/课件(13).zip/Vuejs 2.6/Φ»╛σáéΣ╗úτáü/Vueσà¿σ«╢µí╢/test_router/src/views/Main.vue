<template>
    <div>
        <h2>Main主要内容</h2>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>