<template>
    <div>
        <h3>User-admin页面</h3>
        <h4>{{$route.params.pathMatch}}</h4>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>