<template>
    <div>
        <h2>sidebar侧边栏内容</h2>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>